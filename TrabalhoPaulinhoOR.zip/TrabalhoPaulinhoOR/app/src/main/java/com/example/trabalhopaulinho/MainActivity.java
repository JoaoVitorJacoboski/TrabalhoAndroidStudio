package com.example.trabalhopaulinho;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText etNome;
    private EditText etEmail;
    private EditText etDisciplina;
    private EditText etIdade;
    private EditText etNota1;
    private EditText etNota2;
    private Button btnEnviar;
    private Button btnLimpar;
    private TextView tvResumo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);



         etNome = findViewById(R.id.etNome);
         etEmail = findViewById(R.id.etEmail);
         etIdade = findViewById(R.id.etIdade);
         etDisciplina = findViewById(R.id.etDisciplina);
         etNota1 = findViewById(R.id.etNota1);
         etNota2 = findViewById(R.id.etNota2);
         btnEnviar = findViewById(R.id.btnEnviar);
         btnLimpar = findViewById(R.id.btnLimpar);
         tvResumo = findViewById(R.id.tvResumo);

        btnEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nome = etNome.getText().toString();
                String email = etEmail.getText().toString();
                String idade = etIdade.getText().toString();
                String disciplina = etDisciplina.getText().toString();
                String nota1 = etNota1.getText().toString();
                String nota2 = etNota2.getText().toString();

                StringBuilder mensagemErro = new StringBuilder();


                if (nome.isEmpty()) {
                    mensagemErro.append("O campo Nome está vazio.\n");
                }

                if (!email.contains("@") || email.indexOf("@") <= 3) {
                    mensagemErro.append("O email é inválido.\n");
                }

                if (idade.isEmpty() || !isNumeric(idade) || Integer.parseInt(idade) <= 0) {
                    mensagemErro.append("A idade deve ser um número positivo.\n");
                }

                if (nota1.isEmpty() || !isNumeric(nota1) || Double.parseDouble(nota1) < 0 || Double.parseDouble(nota1) > 10) {
                    mensagemErro.append("A nota 1 deve estar entre 0 e 10.\n");
                }

                if (nota2.isEmpty() || !isNumeric(nota2) || Double.parseDouble(nota2) < 0 || Double.parseDouble(nota2) > 10) {
                    mensagemErro.append("A nota 2 deve estar entre 0 e 10.\n");
                }

                if (mensagemErro.length() > 0) {
                    tvResumo.setText(mensagemErro.toString());
                } else {

                    double media = (Double.parseDouble(nota1) + Double.parseDouble(nota2)) / 2;
                    String status = (media >= 6) ? "Aprovado" : "Reprovado";


                    String resumo = String.format(
                            "Nome: %s\nEmail: %s\nIdade: %s\nDisciplina: %s\nNota 1: %s\nNota 2: %s\nMédia: %.2f\nStatus: %s",
                            nome, email, idade, disciplina, nota1, nota2, media, status
                    );

                    tvResumo.setText(resumo);
                }
            }
        });

        btnLimpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                etNome.setText("");
                etEmail.setText("");
                etIdade.setText("");
                etDisciplina.setText("");
                etNota1.setText("");
                etNota2.setText("");
                tvResumo.setText("");
            }
        });
    }


    private boolean isNumeric(String str) {
        try {
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
